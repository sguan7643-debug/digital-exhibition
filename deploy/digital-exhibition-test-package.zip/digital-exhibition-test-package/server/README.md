# 数智展厅飞书只读代理

该目录是浏览器与飞书开放平台之间的服务端安全边界。浏览器只调用同源
`POST /api/v1/operations/{operationId}`；首页使用 `POST /api/v1/homepage` 聚合读取并通过
`GET /api/v1/sync-jobs/{syncId}` 查询后台同步状态。浏览器不得直接持有飞书应用密钥、租户令牌、
Base token、tableId、viewId 或 fieldId。

## 服务端环境变量

- `FEISHU_APP_ID`：飞书企业自建应用的 App ID。
- `FEISHU_APP_SECRET`：对应 App Secret，仅允许存在于服务端环境变量或密钥管理系统。
- `FEISHU_BASE_TOKEN`：目标多维表格的 app token，仅允许存在于服务端。
- `FEISHU_UPSTREAM_TIMEOUT_MS`：单次飞书上游请求超时，默认 20000 毫秒。
- `FEISHU_READ_BUDGET_MS`：整表读取预算，默认 35000 毫秒。
- `HOMEPAGE_RESPONSE_BUDGET_MS`：首页聚合请求主动收口时间，默认 25000 毫秒且最高 29000 毫秒。
- `FEISHU_APP_LAUNCH_ALLOWED_HOSTS`：允许应用启动的 HTTPS 主机名，多个值用逗号分隔。未配置时默认拒绝外部启动，禁止自动信任多维表格中的任意 URL。
- `EXHIBITION_PUBLIC_ORIGIN`：展厅对外访问来源，例如 `https://test-pre-demo-seaoil.xdata.work`。用于多层反向代理未传递原始 Host 时的写请求同源校验；未配置时会使用 `FEISHU_OAUTH_REDIRECT_URI` 的来源作为兜底。
- `FEISHU_BROWSER_TEST_WRITE_ENABLED=1`：仅在本地联调时允许浏览器进入 TEST_ 写代理；默认关闭。
- `FEISHU_OAUTH_EVIDENCE_PATH`：可选的本地验收文件路径。真实 OAuth 回调成功时只记录身份存在性、权限数量和写权限布尔值，不记录姓名、用户 ID、Cookie、授权码或令牌。
- `FEISHU_OAUTH_TEST_WRITE_ACCEPTANCE=1`：仅限本地联调。真实 OAuth 回调后临时创建 `TEST_` 权限，通过正常复合接口执行 `FAV-003`，随后清理收藏记录和临时权限；结果仅以脱敏布尔值写入上述证据文件。

客户端还必须同时设置 `VITE_EXHIBITION_TEST_WRITES_ENABLED=true` 才会显示受控写入面板。两个开关必须同时开启，任一未开启时页面不显示测试写入口，服务端也拒绝写请求。

缺少任意一项时，代理明确返回 HTTP 503 和 `SERVICE_CREDENTIALS_MISSING`，
不会回退到伪造成功或浏览器直连。

## 当前受控范围

65 个读取接口均已建立服务端字段投影与 schema 合同。文件下载使用绑定当前登录用户、
短时有效的同源访问 URL，飞书文件令牌不返回浏览器：

- `COM-004` 用户/负责人选择器 → 用户字典
- `ANN-001` 公告统计/筛选字典、`ANN-002` 公告列表 → 公告通知
- `APP-001` 应用筛选字典、`APP-002` 应用列表 → 应用索引及五张字典表
- `TAL-002` 人才项目列表 → 人才项目
- `TAL-003` 项目进度列表 → 项目进度
- `MAT-002` 素材列表 → 素材中心

分页默认每页 10 条，可选 10、20、50、100。飞书 `page_token` 只在服务端使用；
页面按页码请求，代理不会把上游令牌下发给浏览器。

首页聚合覆盖 `COM-001`、`COM-002`、`COM-005`、`WB-001`、`WB-002`。同一租户、身份、权限和输入范围只创建一个后台任务；状态查询不访问飞书。服务启动时先预热公共首页表，`GET /api/v1/health/ready` 在预热完成或存在合规旧快照后返回就绪，`GET /api/v1/health/live` 始终用于进程存活检查。

公告通知表当前没有用户已读状态字段，因此只返回公告总数、分类、发布状态、置顶、
发布时间和正文摘要；浏览器中的“全部标为已读”保持禁用，不用发布状态伪造已读状态。

## 仍需外部闭合的边界

- 12 个当前用户接口需要飞书应用登记 OAuth 回调并完成真实用户登录证据；没有用户会话时统一返回 401。
- operation registry 当前共 101 项：65 个只读接口与 36 个仅允许在双重服务端开关下操作 `TEST_` 记录，常规运行不会自动写入。
- Vite 中间件只服务本地开发与 preview；生产环境必须由后端或网关挂载同一分发器。

## 浏览器 TEST_ 写入门禁

36 个写接口只面向获准的测试 Base 和 `TEST_` 前缀记录。每次浏览器写入还必须同时满足：

- 请求来自同源页面，并通过服务端 Origin/Host 校验；
- 已完成飞书 OAuth，服务端能够取得当前用户身份；
- `COM-001` 返回当前用户具备 `operation:{operationId}:execute` 或通配执行权限；
- 页面提供明确确认、唯一幂等键、审计合同与请求哈希；更新、删除和命令类操作提供当前版本；
- 业务键和幂等键均以 `TEST_` 开头，服务端字段白名单和写操作服务再次校验。

页面不会自动执行写入。关闭任一测试开关后，受控面板从 30 个页面全部隐藏；生产运行不得配置这两个开关。

真实浏览器 OAuth 当前仍需在飞书开发者后台登记回调白名单：
`http://127.0.0.1:4173/api/v1/auth/feishu/callback`。未登记时飞书返回错误码 20029，无法完成真实账号登录与授权写入验收。

本地服务启动后可运行 `pnpm feishu:oauth:preflight` 自动检查授权入口、官方授权地址和回调白名单。该命令不会输出一次性 state 或访问令牌；`passed=false` 且 `error20029=true` 表示仍需在飞书开发者后台登记上述回调地址。

运行 `pnpm test:integration:server` 可验证 64 表/1311 字段标识契约、服务端令牌缓存、
默认分页、同源路由、错误脱敏和只读门禁。
