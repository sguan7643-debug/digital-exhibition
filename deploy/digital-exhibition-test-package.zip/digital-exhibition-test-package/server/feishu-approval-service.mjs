import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { FeishuProxyError } from './feishu-open-api-client.mjs';

const TEST_APPROVAL_NAME = '数智展厅海能Work应用上架审批';
const INSTANCE_ID_PATTERN = /^[A-Za-z0-9_-]{1,256}$/;
const STATUSES = new Set(['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED']);
const TEST_KEY_PATTERN = /^TEST_[A-Za-z0-9_-]{1,256}$/;
const REGISTRY_TTL_MS = 30 * 24 * 60 * 60 * 1000;

function requireSession(session) {
  const userId = String(session?.identity?.userId || session?.identity?.openId || '');
  const openId = String(session?.identity?.openId || '');
  if (!userId || !session?.accessToken) throw new FeishuProxyError('USER_AUTH_REQUIRED', '需要先完成飞书用户授权', 401);
  return { userId, openId, accessToken: session.accessToken };
}

function validateInstanceId(value) {
  const instanceId = String(value || '');
  if (!INSTANCE_ID_PATTERN.test(instanceId)) throw new FeishuProxyError('INVALID_APPROVAL_INSTANCE_ID', '审批实例标识非法', 400);
  return instanceId;
}

function normalizeStatus(value) {
  const status = String(value || '').toUpperCase();
  if (!STATUSES.has(status)) throw new FeishuProxyError('APPROVAL_STATUS_INVALID', '审批上游返回了未知或缺失状态', 502);
  return status;
}

export function createFeishuApprovalService({ client, now = Date.now, registry = new Map(), registryFile = '', projectionService = null, approvalNotifier = null, onProjected = null, preWriteGate = null, onInstanceCreated = null } = {}) {
  if (!client?.createApprovalDefinition || !client?.createApprovalInstance || !client?.getApprovalInstance || !client?.approveApprovalTask) {
    throw new Error('飞书审批服务缺少 Approval v4 客户端');
  }
  if (!(registry instanceof Map)) throw new Error('飞书审批实例注册表必须是 Map');
  const testDefinitions = new Map();
  const definitionPromises = new Map();
  const createPromises = new Map();
  const projectionPromises = new Map();
  const notificationPromises = new Map();

  function persistRegistry() {
    if (!registryFile) return;
    const directory = dirname(registryFile);
    mkdirSync(directory, { recursive: true });
    const temporary = `${registryFile}.tmp`;
    writeFileSync(temporary, JSON.stringify([...registry.values()], null, 2), 'utf8');
    renameSync(temporary, registryFile);
  }

  if (registryFile && existsSync(registryFile)) {
    try {
      const stored = JSON.parse(readFileSync(registryFile, 'utf8'));
      if (Array.isArray(stored)) for (const record of stored) {
        if (record && typeof record === 'object' && (record.instanceId || record.registryKey)) {
          registry.set(record.instanceId || `pending:${record.registryKey}`, record);
        }
      }
    } catch {
      throw new FeishuProxyError('APPROVAL_REGISTRY_INVALID', '审批实例注册表无法读取', 500);
    }
  }

  function assertTestKey(value, code = 'TEST_IDEMPOTENCY_REQUIRED') {
    const normalized = String(value || '');
    if (!TEST_KEY_PATTERN.test(normalized)) throw new FeishuProxyError(code, '测试审批必须使用 TEST_ 业务键和幂等键', 400);
    return normalized;
  }

  function sessionContext(session) {
    const identity = session?.identity || {};
    const userId = String(identity.userId || '');
    const openId = String(identity.openId || '');
    const subject = String(identity.subject || userId || openId || '');
    if (!subject || !session?.accessToken) throw new FeishuProxyError('USER_AUTH_REQUIRED', '需要先完成飞书用户授权', 401);
    return {
      userId: userId || subject,
      subject,
      openId,
      tenantKey: String(identity.tenantKey || identity.tenantId || ''),
      orgId: String(identity.orgId || identity.organizationId || ''),
      permissionSnapshot: Array.isArray(identity.permissions) ? [...new Set(identity.permissions.map(String))].sort() : [],
      accessToken: session.accessToken
    };
  }

  function registryKey(context, businessKey, idempotencyKey) {
    return [context.subject, context.tenantKey, context.orgId, businessKey, idempotencyKey].join('\u0000');
  }

  function stableRequestId(context, key) {
    const digest = createHash('sha256').update(`${context.subject}\u0000${context.tenantKey}\u0000${key}`).digest('hex').slice(0, 32);
    return `TEST_${digest}`;
  }

  function normalizeApplication(input = {}, fallback = {}) {
    const source = input && typeof input === 'object' ? input : {};
    const result = {};
    for (const key of ['name', 'applicationCode', 'summary', 'description', 'webAddress', 'mobileAddress', 'applicant', 'department', 'contact', 'contactDepartment', 'contactPhone', 'contactEmail', 'phone', 'email', 'domain', 'users', 'accessDepartment', 'roles', 'scope', 'collaboration', 'scenario', 'remarks']) {
      const value = source[key] ?? fallback[key];
      if (value != null) result[key] = String(value).trim().slice(0, 4000);
    }
    for (const key of ['attemptId', 'applicationId', 'businessId', 'runId']) {
      const value = source[key] ?? fallback[key];
      if (value != null) result[key] = String(value).trim().slice(0, 256);
    }
    const detailFields = source.detailFields ?? fallback.detailFields;
    if (detailFields && typeof detailFields === 'object' && !Array.isArray(detailFields)) {
      result.detailFields = Object.fromEntries(Object.entries(detailFields).map(([key, value]) => [
        String(key).trim().slice(0, 128),
        String(value ?? '').trim().slice(0, 4000)
      ]));
    }
    const uploads = source.uploads ?? fallback.uploads;
    if (Array.isArray(uploads)) {
      result.uploads = uploads
        .filter(file => file && typeof file === 'object' && ['APPLICATION_ICON', 'APPLICATION_ATTACHMENT'].includes(String(file.purpose || '')))
        .map(file => ({
          uploadId: String(file.uploadId || '').slice(0, 256),
          purpose: String(file.purpose || ''),
          originalName: String(file.originalName || '').slice(0, 512),
          sizeBytes: Number(file.sizeBytes || 0),
          mimeType: String(file.mimeType || '').slice(0, 256),
          sha256: String(file.sha256 || '').slice(0, 64),
          uploadedAt: String(file.uploadedAt || '').slice(0, 64),
          fileToken: String(file.fileToken || '').slice(0, 1024)
        }))
        .filter(file => file.uploadId.startsWith('TEST_') && file.fileToken);
    }
    return result;
  }

  function requireAuthorizationScope(application) {
    if (!String(application?.users || '').trim() || !String(application?.accessDepartment || '').trim()) {
      throw new FeishuProxyError('APPROVAL_AUTHORIZATION_REQUIRED', '海能Work审批必须填写适用用户和适用部门', 400);
    }
  }

  function hydrateApplication(record, result = {}) {
    const form = result.formValues && typeof result.formValues === 'object' ? result.formValues : {};
    record.application = normalizeApplication(record.application, {
      name: form.application_name || record.title,
      applicationCode: form.application_code || record.applicationCode,
      summary: form.application_description || record.description,
      description: form.application_description || record.description
    });
  }

  async function syncProjection(record, session, { throwOnFailure = true } = {}) {
    if (!['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED'].includes(record.status) || !projectionService?.publish) return;
    const projectedContractVersion = String(projectionService.version || 'unversioned');
    if (record.projectionStatus === 'SYNCED' && record.projectedApprovalStatus === record.status && record.projectedContractVersion === projectedContractVersion) return;
    const key = record.instanceId || record.registryKey;
    if (!projectionPromises.has(key)) projectionPromises.set(key, (async () => {
      try {
        if (typeof preWriteGate === 'function') await preWriteGate({ session });
        const projection = await projectionService.publish(record);
        record.projectionStatus = 'SYNCED';
        record.projectedApprovalStatus = record.status;
        record.projectedContractVersion = projectedContractVersion;
        record.projection = projection;
        record.projectionError = '';
        record.projectedAt = now();
        persistRegistry();
        if (typeof onProjected === 'function') await onProjected(record, projection);
        return projection;
      } catch (error) {
        record.projectionStatus = 'FAILED';
        record.projectionError = String(error?.code || error?.message || 'APPROVAL_PROJECTION_FAILED').slice(0, 240);
        persistRegistry();
        throw error;
      }
    })().finally(() => projectionPromises.delete(key)));
    try {
      return await projectionPromises.get(key);
    } catch (error) {
      if (throwOnFailure) throw error;
      return null;
    }
  }

  async function syncApprovalNotification(record) {
    if (record.status !== 'APPROVED' || !approvalNotifier?.notify) return null;
    if (projectionService?.publish && record.projectionStatus !== 'SYNCED') return null;
    if (record.notificationStatus === 'SENT') return record.notification;
    const key = record.instanceId || record.registryKey;
    if (!notificationPromises.has(key)) notificationPromises.set(key, (async () => {
      try {
        const result = await approvalNotifier.notify(record, {
          alreadySent: Array.isArray(record.notifiedRecipientIds) ? record.notifiedRecipientIds : []
        });
        record.notifiedRecipientIds = result.sentRecipientIds;
        record.notificationStatus = result.complete ? 'SENT' : 'PENDING';
        record.notification = result;
        record.notificationError = '';
        if (result.complete) record.notifiedAt = now();
        persistRegistry();
        return result;
      } catch (error) {
        if (Array.isArray(error?.sentRecipientIds)) {
          record.notifiedRecipientIds = [...new Set([
            ...(Array.isArray(record.notifiedRecipientIds) ? record.notifiedRecipientIds : []),
            ...error.sentRecipientIds.map(String)
          ])];
        }
        record.notificationStatus = 'FAILED';
        record.notificationError = String(error?.code || error?.message || 'FEISHU_ONBOARDING_NOTIFICATION_FAILED').slice(0, 240);
        persistRegistry();
        return null;
      }
    })().finally(() => notificationPromises.delete(key)));
    return notificationPromises.get(key);
  }

  function recordFor(instanceId, context, { resourceId = '' } = {}) {
    const record = registry.get(instanceId);
    if (!record) throw new FeishuProxyError('APPROVAL_INSTANCE_NOT_REGISTERED', '审批实例不是本服务创建的 TEST_ 实例', 404);
    const creatorSubject = String(record.creatorSubject || record.creatorUserId || '');
    if (creatorSubject !== context.subject || (record.creatorOpenId && context.openId && record.creatorOpenId !== context.openId)) {
      throw new FeishuProxyError('APPROVAL_INSTANCE_FORBIDDEN', '无权访问其他用户的测试审批实例', 403);
    }
    if (record.tenantKey && record.tenantKey !== context.tenantKey) throw new FeishuProxyError('APPROVAL_INSTANCE_TENANT_MISMATCH', '审批实例不属于当前租户', 403);
    if (record.orgId && record.orgId !== context.orgId) throw new FeishuProxyError('APPROVAL_INSTANCE_ORG_MISMATCH', '审批实例不属于当前组织', 403);
    if (resourceId && record.resourceId !== resourceId) throw new FeishuProxyError('APPROVAL_INSTANCE_RESOURCE_MISMATCH', '审批实例不属于当前资源', 403);
    if (record.expiresAt <= now() || record.cleanupStatus !== 'ACTIVE') {
      record.cleanupStatus = 'EXPIRED';
      persistRegistry();
      throw new FeishuProxyError('APPROVAL_INSTANCE_EXPIRED', '测试审批实例已过期或已清理', 410);
    }
    return record;
  }

  async function ensureTestDefinition(session) {
    const context = sessionContext(session);
    const definitionKey = `${context.subject}\u0000${context.tenantKey}\u0000${context.orgId}`;
    const existing = testDefinitions.get(definitionKey) || [...registry.values()].find(record => record.creatorSubject === context.subject && record.tenantKey === context.tenantKey && record.orgId === context.orgId && record.approvalCode)?.approvalCode && Object.freeze({ approvalCode: [...registry.values()].find(record => record.creatorSubject === context.subject && record.tenantKey === context.tenantKey && record.orgId === context.orgId && record.approvalCode)?.approvalCode, approvalName: TEST_APPROVAL_NAME, creatorUserId: context.userId, createdAt: new Date(now()).toISOString(), expiresAt: now() + REGISTRY_TTL_MS });
    if (existing) return existing;
    if (!definitionPromises.has(definitionKey)) definitionPromises.set(definitionKey, (async () => {
      if (typeof preWriteGate === 'function') await preWriteGate({ session });
      const created = await client.createApprovalDefinition({
        approvalName: TEST_APPROVAL_NAME,
        description: '数智展厅海能Work应用上线审批',
        approverUserId: context.userId
      });
      if (!created?.approvalCode) throw new FeishuProxyError('APPROVAL_DEFINITION_FAILED', '测试审批定义创建失败', 502);
      const definition = Object.freeze({ approvalCode: created.approvalCode, approvalName: TEST_APPROVAL_NAME, creatorUserId: context.userId, createdAt: new Date(now()).toISOString(), expiresAt: now() + REGISTRY_TTL_MS });
      testDefinitions.set(definitionKey, definition);
      return definition;
    })().finally(() => definitionPromises.delete(definitionKey)));
    return definitionPromises.get(definitionKey);
  }

  async function createInstance(input = {}, session) {
    const context = sessionContext(session);
    const { userId } = context;
    if (input.applicationType !== 'T005') throw new FeishuProxyError('UNSUPPORTED_APPROVAL_TYPE', '仅海能Work应用使用飞书审批', 400);
    const title = String(input.title || '').trim();
    if (!title || title.length > 200) throw new FeishuProxyError('INVALID_APPROVAL_TITLE', '审批标题不能为空且不能超过 200 个字符', 400);
    const applicationCode = String(input.applicationCode || '');
    const resourceId = String(input.resourceId || '');
    if (!applicationCode || applicationCode.length > 128 || !TEST_KEY_PATTERN.test(resourceId)) throw new FeishuProxyError('TEST_RESOURCE_REQUIRED', '测试审批必须绑定 TEST_ 应用资源', 400);
    const businessKey = assertTestKey(input.businessKey);
    const idempotencyKey = assertTestKey(input.idempotencyKey);
    const key = registryKey(context, businessKey, idempotencyKey);
    const existing = [...registry.values()].find(record => record.registryKey === key);
    if (existing && existing.expiresAt <= now()) throw new FeishuProxyError('APPROVAL_IDEMPOTENCY_EXPIRED', '测试审批幂等记录已过期', 409);
    if (existing?.instanceId) {
      if (typeof onInstanceCreated === 'function') await onInstanceCreated(existing);
      await syncProjection(existing, session);
      await syncApprovalNotification(existing);
      return Object.freeze({ applicationId: String(existing.applicationId || ''), instanceId: existing.instanceId, status: existing.status });
    }
    const application = normalizeApplication(input.application, { name: title, applicationCode, summary: input.description, description: input.description });
    requireAuthorizationScope(application);
    if (!createPromises.has(key)) createPromises.set(key, (async () => {
      const definition = await ensureTestDefinition(session);
      const record = existing || { instanceId: '', approvalCode: definition.approvalCode, creatorUserId: userId, creatorSubject: context.subject, creatorOpenId: context.openId, tenantKey: context.tenantKey, orgId: context.orgId, resourceId, permissionSnapshot: context.permissionSnapshot, businessKey, idempotencyKey, registryKey: key, requestId: stableRequestId(context, key), createdAt: now(), expiresAt: now() + REGISTRY_TTL_MS, cleanupStatus: 'ACTIVE', status: 'PENDING', projectionStatus: 'PENDING' };
      record.title = title;
      record.applicationId = String(input.applicationId || record.applicationId || `TEST_APPLICATION_${createHash('sha256').update(key).digest('hex').slice(0, 24)}`);
      record.businessId = String(input.businessId || record.businessId || '');
      record.runId = String(input.runId || record.runId || '');
      record.applicationCode = applicationCode;
      record.applicationType = 'T005';
      record.description = String(input.description || 'TEST_数智展厅端到端验收');
      record.application = application;
      if (!existing) registry.set(`pending:${key}`, record);
      persistRegistry();
      try {
        const created = await client.createApprovalInstance({
          approvalCode: record.approvalCode,
          applicantUserId: userId,
          approverUserId: userId,
          title,
          applicationCode,
          description: String(input.description || 'TEST_数智展厅端到端验收'),
          requestId: record.requestId
        });
        const instanceId = validateInstanceId(created?.instanceCode);
        const status = normalizeStatus(created.status);
        registry.delete(`pending:${key}`);
        record.instanceId = instanceId;
        record.status = status;
        registry.set(instanceId, record);
        persistRegistry();
        if (typeof onInstanceCreated === 'function') await onInstanceCreated(record);
        await syncProjection(record, session);
        await syncApprovalNotification(record);
        return Object.freeze({ applicationId: record.applicationId, instanceId, status });
      } catch (error) {
        persistRegistry();
        throw error;
      }
    })().finally(() => createPromises.delete(key)));
    return createPromises.get(key);
  }

  async function getInstance(instanceId, session, options = {}) {
    const context = sessionContext(session);
    const normalized = validateInstanceId(instanceId);
    const record = recordFor(normalized, context, options);
    const result = await client.getApprovalInstance(normalized);
    if (result.approvalCode !== record.approvalCode) throw new FeishuProxyError('APPROVAL_DEFINITION_MISMATCH', '审批实例不属于本服务 TEST_ 定义', 403);
    record.status = normalizeStatus(result.status);
    hydrateApplication(record, result);
    persistRegistry();
    await syncProjection(record, session, { throwOnFailure: false });
    await syncApprovalNotification(record);
    return Object.freeze({
      instanceId: normalized,
      status: record.status,
      projectionStatus: String(record.projectionStatus || ''),
      projectionError: record.projectionStatus === 'FAILED' ? String(record.projectionError || 'APPROVAL_PROJECTION_FAILED') : '',
      notificationStatus: String(record.notificationStatus || ''),
      notificationError: record.notificationStatus === 'FAILED' ? String(record.notificationError || 'FEISHU_ONBOARDING_NOTIFICATION_FAILED') : ''
    });
  }

  async function approveTestTask(instanceId, session, options = {}) {
    const context = sessionContext(session);
    const { userId } = context;
    const normalized = validateInstanceId(instanceId);
    const record = recordFor(normalized, context, options);
    const current = await client.getApprovalInstance(normalized);
    if (current.approvalCode !== record.approvalCode) throw new FeishuProxyError('APPROVAL_DEFINITION_MISMATCH', '审批实例不属于本服务 TEST_ 定义', 403);
    const task = (current.taskList || []).find(item => item.status === 'PENDING' && (!item.userId || item.userId === userId));
    if (!task?.id) throw new FeishuProxyError('APPROVAL_TASK_NOT_AVAILABLE', '当前用户没有可审批的测试任务', 409);
    await client.approveApprovalTask({
      approvalCode: current.approvalCode,
      instanceCode: normalized,
      userId,
      taskId: task.id,
      comment: 'TEST_数智展厅端到端验收审批'
    });
    record.status = 'APPROVED';
    persistRegistry();
    await syncProjection(record, session, { throwOnFailure: false });
    await syncApprovalNotification(record);
    return Object.freeze({
      instanceId: normalized,
      status: 'APPROVED',
      projectionStatus: String(record.projectionStatus || ''),
      projectionError: record.projectionStatus === 'FAILED' ? String(record.projectionError || 'APPROVAL_PROJECTION_FAILED') : '',
      notificationStatus: String(record.notificationStatus || ''),
      notificationError: record.notificationStatus === 'FAILED' ? String(record.notificationError || 'FEISHU_ONBOARDING_NOTIFICATION_FAILED') : ''
    });
  }

  async function reconcile(session) {
    const context = sessionContext(session);
    let checked = 0;
    let published = 0;
    for (const record of registry.values()) {
      if (!record?.instanceId || record.cleanupStatus !== 'ACTIVE') continue;
      if (String(record.creatorSubject || record.creatorUserId || '') !== context.subject) continue;
      if (record.tenantKey && record.tenantKey !== context.tenantKey) continue;
      if (record.orgId && record.orgId !== context.orgId) continue;
      if (record.status !== 'APPROVED' && record.status !== 'PENDING') continue;
      checked += 1;
      const current = await client.getApprovalInstance(record.instanceId);
      if (current.approvalCode !== record.approvalCode) continue;
      record.status = normalizeStatus(current.status);
      hydrateApplication(record, current);
      const wasSynced = record.projectionStatus === 'SYNCED' && record.projectedApprovalStatus === record.status;
      persistRegistry();
      await syncProjection(record, session);
      await syncApprovalNotification(record);
      if (!wasSynced && record.projectionStatus === 'SYNCED') published += 1;
    }
    return Object.freeze({ checked, published });
  }

  function cleanupExpired() {
    let count = 0;
    for (const record of registry.values()) if (record.expiresAt <= now() && record.cleanupStatus === 'ACTIVE') { record.cleanupStatus = 'EXPIRED'; count += 1; }
    if (count) persistRegistry();
    return count;
  }

  return Object.freeze({ ensureTestDefinition, createInstance, getInstance, approveTestTask, reconcile, cleanupExpired });
}
